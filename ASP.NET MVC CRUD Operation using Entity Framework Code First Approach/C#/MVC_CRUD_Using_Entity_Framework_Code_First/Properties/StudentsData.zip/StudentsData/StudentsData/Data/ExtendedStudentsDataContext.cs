﻿using Microsoft.EntityFrameworkCore;
using StudentsData.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentsData.Data
{
    public class ExtendedStudentsDataContext : StudentsDataContext
	{
		public ExtendedStudentsDataContext(DbContextOptions<StudentsDataContext> options)
			: base(options)
		{
		}

		//public DbSet<StudentsData.Models.Students> Students { get; set; }
		public DbSet<StudentsData.Models.Blog> Blog { get; set; }
	}
}
