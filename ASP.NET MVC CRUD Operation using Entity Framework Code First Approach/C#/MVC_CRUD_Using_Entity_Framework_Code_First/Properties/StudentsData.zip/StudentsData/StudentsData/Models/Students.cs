﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace StudentsData.Models
{
    public class Students
    {
		public int Id { get; set; }
		[Required]
		public string  Name { get; set; }
		public string Class { get; set; }
		public List<FatherDetail> Father { get; set; }
	}
}
